# Roblox-like Multiplayer 3D Game

This is a real-time multiplayer 3D game built with React, Three.js (React Three Fiber), Cannon-es (Physics), and Socket.io.

## Features

- **Real-time Multiplayer**: See other players move and change colors.
- **3D Physics**: Box and sphere collisions.
- **Avatar Customization**: Change your sphere's color.
- **Building System**: 
  - **Left Click**: Place an orange block at the target.
  - **Right Click**: Remove a block.
- **Sample Obby**: An obstacle course to test your jumping skills.

## Getting Started

### Prerequisites

- Node.js (v18 or higher recommended)
- npm

### Installation

1. Clone the repository.
2. Install dependencies:
   ```bash
   npm install
   ```

### Running the Game

To start both the backend server and the frontend development server simultaneously, run:

```bash
npm run dev
```

The game will be available at `http://localhost:5173`.
The multiplayer server runs on `http://localhost:3001`.

## Controls

- **WASD / Arrow Keys**: Move
- **Space**: Jump
- **Mouse**: Look around (click to lock)
- **Esc**: Unlock mouse
- **Left Click**: Place Block
- **Right Click**: Delete Block
