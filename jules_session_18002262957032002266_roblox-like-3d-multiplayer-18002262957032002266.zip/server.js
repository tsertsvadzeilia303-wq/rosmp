import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const players = {};
const blocks = [];

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Initialize player state
  players[socket.id] = {
    id: socket.id,
    position: [0, 5, 0],
    rotation: [0, 0, 0],
    color: '#' + Math.floor(Math.random()*16777215).toString(16),
  };

  // Send current state to the new player
  socket.emit('init', { players, blocks });

  // Broadcast the new player to everyone else
  socket.broadcast.emit('playerJoin', players[socket.id]);

  socket.on('move', (data) => {
    if (players[socket.id]) {
      players[socket.id].position = data.position;
      players[socket.id].rotation = data.rotation;
      socket.broadcast.emit('playerMove', players[socket.id]);
    }
  });

  socket.on('updateAvatar', (data) => {
    if (players[socket.id]) {
      players[socket.id].color = data.color;
      io.emit('playerUpdate', players[socket.id]);
    }
  });

  socket.on('addBlock', (block) => {
    blocks.push(block);
    io.emit('blockAdded', block);
  });

  socket.on('removeBlock', (position) => {
    const index = blocks.findIndex(b => 
      b.position[0] === position[0] && 
      b.position[1] === position[1] && 
      b.position[2] === position[2]
    );
    if (index !== -1) {
      blocks.splice(index, 1);
      io.emit('blockRemoved', position);
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    delete players[socket.id];
    io.emit('playerLeave', socket.id);
  });
});

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
