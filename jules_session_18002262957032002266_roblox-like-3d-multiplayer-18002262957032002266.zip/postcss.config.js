import tailwindjs from '@tailwindcss/postcss';
import autoprefixer from 'autoprefixer';

export default {
  plugins: [
    tailwindjs,
    autoprefixer,
  ],
};
