import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Sky, PointerLockControls, Stars } from '@react-three/drei';
import { Physics } from '@react-three/cannon';
import { Ground } from './components/Ground';
import { Player } from './components/Player';
import { Cube } from './components/Cube';
import { Obby } from './components/Obby';
import { RemotePlayer } from './components/RemotePlayer';
import { useMultiplayer } from './hooks/useMultiplayer';
import { AvatarCustomizer } from './components/AvatarCustomizer';
import { BuildingSystem } from './components/BuildingSystem';
import './App.css';

function App() {
  const { socket, players, blocks } = useMultiplayer('http://localhost:3001');
  
  const currentPlayer = socket ? players[socket.id] : null;

  return (
    <div className="w-full h-screen bg-black">
      <Canvas shadows camera={{ fov: 45 }}>
        <Sky sunPosition={[100, 10, 100]} />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        <ambientLight intensity={1.5} />
        <directionalLight position={[10, 20, 10]} intensity={1.5} castShadow />
        
        <Physics gravity={[0, -9.81, 0]}>
          <Ground />
          
          {socket && currentPlayer && (
            <Player socket={socket} color={currentPlayer.color} />
          )}

          {Object.values(players)
            .filter((p) => p.id !== socket?.id)
            .map((p) => (
              <RemotePlayer key={p.id} position={p.position} rotation={p.rotation} color={p.color} />
            ))}

          {blocks.map((block, index) => (
            <Cube key={index} position={block.position} color={block.color} />
          ))}
          
          <Obby />
        </Physics>

        <PointerLockControls />
        {socket && <BuildingSystem socket={socket} />}
      </Canvas>

      <div className="fixed top-4 left-4 text-white pointer-events-none">
        <h1 className="text-2xl font-bold">Roblox-like Multiplayer</h1>
        <p>WASD to Move | Space to Jump</p>
        <p>Click to Lock Mouse | Left Click to Build | Right Click to Delete</p>
        <p>Players Online: {Object.keys(players).length}</p>
      </div>

      {socket && currentPlayer && (
        <AvatarCustomizer socket={socket} currentColor={currentPlayer.color} />
      )}
    </div>
  );
}

export default App;
